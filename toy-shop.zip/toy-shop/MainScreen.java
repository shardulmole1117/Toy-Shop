import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import javax.imageio.*;

class MainPanel extends JPanel{
	public void paintComponent(Graphics g){
		try{
			Image img = ImageIO.read(new java.io.File("images/main.jpg"));
          		g.drawImage(img,0,0,getWidth(),getHeight(),null);
		}
		catch(Exception e){}
	}
}


class MainScreen extends JFrame{
	private JPanel panNorth;
	private JButton btnCustomer,btnDealer,btnProduct,btnPurchase,btnBill,btnReports,btnExit;

	public MainScreen(){
		btnCustomer = new JButton("Customer");
		btnDealer = new JButton("Dealer");
		btnProduct = new JButton("Product");
		btnPurchase = new JButton("Purchase");
		btnBill = new JButton("Bill");
		btnReports = new JButton("Reports");
		btnExit = new JButton("Exit");

		panNorth = new JPanel();
		panNorth.setLayout(new FlowLayout());
		panNorth.add(btnCustomer);
		panNorth.add(btnDealer);
		panNorth.add(btnProduct);
		panNorth.add(btnPurchase);
		panNorth.add(btnBill);
		panNorth.add(btnReports);
		panNorth.add(btnExit);

		btnCustomer.setMnemonic('C');
		btnDealer.setMnemonic('C');
		btnProduct.setMnemonic('P');
		btnPurchase.setMnemonic('r');
		btnBill.setMnemonic('B');
		btnReports.setMnemonic('o');
		btnExit.setMnemonic('x');

	    	setTitle("Toy Billing System v1.1");
		Rectangle bounds = getMaximizedBounds();
		setMaximizedBounds(bounds);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		add(new MainPanel(),"Center");
		add(panNorth,"North");
    		setVisible(true);
    		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		ButtonHandler bh = new ButtonHandler();
		btnCustomer.addActionListener(bh);
		btnDealer.addActionListener(bh);
		btnProduct.addActionListener(bh);
		btnPurchase.addActionListener(bh);
		btnBill.addActionListener(bh);
		btnReports.addActionListener(bh);
		btnExit.addActionListener(bh);
	}

	class ButtonHandler implements ActionListener{
		public void actionPerformed(ActionEvent ae){
			if(ae.getSource()==btnCustomer) new Customer();
			if(ae.getSource()==btnDealer) new Dealer();
			if(ae.getSource()==btnProduct) new Product();
			if(ae.getSource()==btnPurchase) new Purchase();
			if(ae.getSource()==btnBill) new Bill();
			if(ae.getSource()==btnReports) new Reports();
			if(ae.getSource()==btnExit) System.exit(0);
		}
	}
	public static void main(String[] args) {
		new MainScreen();
	}
}
