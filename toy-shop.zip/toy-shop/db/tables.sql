create table admin(
	admin_id text primary key,
	admin_pwd text
);

insert into admin values('admin','admin');

create table item(
	ino serial primary key,
	iname text,
	iqty int,
	iprice int,
	icategory text
);

insert into item(iname,iqty,iprice,icategory) values
('Magnetic Letters',90,120,'Two-Five'),
('Magical Slate',100,150,'Two-Five'),
('Musical Mic',60,130,'Two-Five'),
('Counting Frame',160,170,'Two-Five'),
('School Bus',200,270,'Two-Five'),
('Piano',200,270,'Two-Five'),
('Clock Learn Board',150,150,'Two-Five'),
('Binocular',80,350,'Two-Five'),
('Magnetic Numbers',100,120,'Two-Five'),
('Animal Cards',200,60,'Two-Five'),
('Number Cards',200,60,'Two-Five'),
('Fruits Cards',200,60,'Two-Five'),
('Number Cubes',130,200,'Two-Five'),
('Body Parts Cards',150,60,'Two-Five'),
('Water Game Board',110,70,'Two-Five'),
('Speaking Duck',80,260,'Six-Ten'),
('JCB',120,200,'Six-Ten'),
('Train',140,400,'Six-Ten'),
('Puzzle',70,150,'Six-Ten'),
('Riding Horse',80,480,'Six-Ten'),
('Rubics Cube',100,280,'Six-Ten'),
('Cars',170,240,'Six-Ten'),
('Bikes',120,100,'Six-Ten'),
('Helicopter',70,140,'Six-Ten'),
('Elephant',60,80,'Six-Ten'),
('Lazer',200,90,'Six-Ten'),
('Transformer',80,150,'Six-Ten'),
('Cartoon Toys',80,50,'Six-Ten'),
('Bay Blade',160,350,'Six-Ten'),
('Yoyo',60,70,'Six-Ten'),
('Cycle',10,10000,'Eleven-Sixteen'),
('Monopoly',20,1000,'Eleven-Sixteen'),
('Mirror Cube',15,400,'Eleven-Sixteen'),
('Funskool',25,800,'Eleven-Sixteen'),
('Robot Kits',30,1200,'Eleven-Sixteen'),
('Dart Board',20,150,'Eleven-Sixteen'),
('Monster Truck',40,300,'Eleven-Sixteen'),
('Carrom Board',10,4000,'Eleven-Sixteen'),
('Triangle Rubik Cube',20,600,'Eleven-Sixteen'),
('UNO cards',30,100,'Eleven-Sixteen'),
('Football Table Soccer',15,1500,'Eleven-Sixteen'),
('Barbie Doll Set',25,1300,'Eleven-Sixteen'),
('Roller Coastal',10,1800,'Eleven-Sixteen'),
('Chess Board',35,700,'Eleven-Sixteen'),
('Snake & Ladder',30,500,'Eleven-Sixteen'),
('Magnetic Letters',90,120,'Eleven-Sixteen'),
('Magical Slate',100,150,'Eleven-Sixteen'),
('Musical Mic',60,130,'Eleven-Sixteen'),
('Counting Frame',160,170,'Eleven-Sixteen'),
('School Bus',200,270,'Eleven-Sixteen'),
('Piano',200,270,'Eleven-Sixteen'),
('Clock Learn Board',150,150,'All'),
('Binocular',80,350,'All'),
('Magnetic Numbers',100,120,'All'),
('Animal Cards',200,60,'All'),
('Number Cards',200,60,'All'),
('Fruits Cards',200,60,'All'),
('Number Cubes',130,200,'All'),
('Body Parts Cards',150,60,'All'),
('Water Game Board',110,70,'All'),
('Speaking Duck',80,260,'All'),
('JCB',120,200,'All'),
('Train',140,400,'All'),
('Puzzle',70,150,'All'),
('Riding Horse',80,480,'All'),
('Rubics Cube',100,280,'All'),
('Cars',170,240,'All'),
('Bikes',120,100,'All'),
('Helicopter',70,140,'All'),
('Elephant',60,80,'All'),
('Lazer',200,90,'All'),
('Transformer',80,150,'All'),
('Cartoontoys',80,50,'All'),
('Bay Blade',160,350,'All'),
('Yoyo',60,70,'All'),
('Cycle',10,10000,'All'),
('Monopoly',20,1000,'All'),
('Mirror Cube',15,400,'All'),
('Funskool',25,800,'All'),
('Robot Kits',30,1200,'All'),
('Dart Board',20,150,'All'),
('Monster Truck',40,300,'All'),
('Carrom Board',10,4000,'All'),
('Triangle Rubik Cube',20,600,'All'),
('UNO cards',30,100,'All'),
('FootballTableSoccer',15,1500,'All'),
('Barbie Doll Set',25,1300,'All'),
('Roller Coastal',10,1800,'All'),
('Chess Board',35,700,'All'),
('Snake&Ladder',30,500,'All');


create table Dealer(
	d_no serial primary key,
	d_name text,
	d_phno text,
	d_addr text
);

insert into Dealer(d_name,d_phno,d_addr) values
('Mahesh Kadam','8983027222','Wanavdi'),
('Praveen Basheti','8668200923','Nana Peth'),
('Chirag Jagtap','9922917612','Aple Ghar'),
('Snehankit Konde','7030291920','Baner'),
('Pavan Bhujbal','9096361022','Bypass'),
('Shrinath Choudhari','7304910134','Kharadi'),
('Shreyas Bhilare','9850310823','Wadgaon Sheri'),
('Sagar Kumbhar','9883903811','Bund Garden'),
('Tushar Kumbhar','8888255612','Bund Garden'),
('Sagar Naik','7066081562','Wanavdi');

create table Customer(
	c_no serial primary key,
	c_name text,
	c_phno text,
	c_addr text
);

insert into Customer(c_name,c_phno,c_addr) values
('John Abraham','9823375979','Akurdi'),
('Ajay Devgan','9833375977','Chinchwad'),
('Madhuri Dixit','9822290095','Bhosari'),
('Hema Malini','8698958117','Pimpri');


create table BillHeader(
	b_no serial primary key,
	b_date date,
	b_amt float,
	c_no int references Customer(c_no) on delete cascade
);

create table BillDetails(
	b_no int references BillHeader(b_no) on delete cascade,
	ino int references item(ino) on delete cascade,
	qty int
);

create table PurchaseHeader(
	p_no serial primary key,
	p_date date,
	p_amt float,
	d_no int references Dealer(d_no) on delete cascade
);

create table PurchaseDetails(
	p_no int references PurchaseHeader(p_no) on delete cascade,
	ino int references Item(ino) on delete cascade,
	qty int,
	price float	
);

