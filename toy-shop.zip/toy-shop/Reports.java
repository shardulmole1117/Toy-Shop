import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Reports extends JFrame{
	private JButton btnCustomer,btnDealer,btnProduct,btnPurchaseSale,btnExit,btnReorderList;

	public Reports(){
		btnCustomer = new JButton("Customer");
		btnDealer = new JButton("Dealer");
		btnProduct = new JButton("Product");
		btnPurchaseSale = new JButton("Purchase/Sale");
		btnReorderList = new JButton("Reorder List");
		btnExit = new JButton("Exit");

    		setTitle("Reports");
    		setSize(400,200);
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
    		int x = (int) ((dimension.getWidth() - getWidth()) / 2);
    		int y = (int) ((dimension.getHeight() - getHeight()) / 2);
    		setLocation(x, y);
		setLayout(new GridLayout(6,1));
    		add(btnCustomer);
    		add(btnDealer);
    		add(btnProduct);
    		add(btnPurchaseSale);
		add(btnReorderList);
    		add(btnExit);
    		setVisible(true);
    		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    		ButtonHandler bh = new ButtonHandler();
    		btnCustomer.addActionListener(bh);
    		btnDealer.addActionListener(bh);
    		btnProduct.addActionListener(bh);
    		btnPurchaseSale.addActionListener(bh);
    		btnExit.addActionListener(bh);
		btnReorderList.addActionListener(bh);
	}

	class ButtonHandler implements ActionListener{
		public void actionPerformed(ActionEvent ae){
			if(ae.getSource()==btnCustomer) new ViewAllCustomer();
			if(ae.getSource()==btnDealer) new ViewAllDealer();
			if(ae.getSource()==btnProduct) new ViewAllProduct();
			if(ae.getSource()==btnPurchaseSale) new PurchaseSale();
			if(ae.getSource()==btnExit) dispose();
			if(ae.getSource()==btnReorderList) new ViewReorderList();
		}
	}
	public static void main(String[] args) {
		new Reports();
	}
}		
	

