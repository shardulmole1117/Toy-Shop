import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame {
	private JPasswordField txtPass;
	private JComboBox cmbUserName;
	private JLabel lblUserName,lblPassword;
	private JButton btnOK,btnCancel;

	private Connection con;
  	private Statement s;
  	private PreparedStatement ps;
  	private ResultSet rs;

	public static void main(String[] args) {
		new Login();
	}

	public Login() {
		lblUserName = new JLabel("User Name:");
		lblPassword = new JLabel("Password:");

		txtPass = new JPasswordField();
		cmbUserName = new JComboBox();

		btnOK = new JButton("OK");
		btnCancel = new JButton("Cancel");

		lblUserName.setDisplayedMnemonic('N');
		lblPassword.setDisplayedMnemonic('P');

		lblUserName.setLabelFor(cmbUserName);
		lblPassword.setLabelFor(txtPass);

		btnOK.setMnemonic('O');
		btnCancel.setMnemonic('C');

		setTitle("Login");
		setLayout(new GridLayout(3, 2));
		setSize(350,150);
		add(lblUserName);
		add(cmbUserName);
		add(lblPassword);
		add(txtPass);
		add(btnOK);
		add(btnCancel);		
    		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    		double width = screenSize.getWidth();
    		double height = screenSize.getHeight();
    		setLocation((int)((width-getWidth())/2),(int)((height-getHeight())/2));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					ps = con.prepareStatement("select * from admin where admin_id=? and admin_pwd=?");
					String uid = cmbUserName.getSelectedItem().toString();
					String pass = txtPass.getText();
					ps.setString(1,uid);
					ps.setString(2,pass);
					rs = ps.executeQuery();
					if(rs.next()){
						JOptionPane.showMessageDialog(null,"Login Successful.");
						new MainScreen();
						dispose();
					}
					else{
						JOptionPane.showMessageDialog(null,"Login Failed.");
						cmbUserName.requestFocus();
					}
		    		}
		    		catch(Exception e){
		      			JOptionPane.showMessageDialog(null,e);
		      			dispose();
		    		}
			}
		});
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});

		try{
      			Class.forName("org.postgresql.Driver");
      			con = DriverManager.getConnection("jdbc:postgresql:toy","postgres","");
			s = con.createStatement();
			rs = s.executeQuery("select admin_id from admin");

			while(rs.next()){
				cmbUserName.addItem(rs.getString(1));
			}
    		}
    		catch(Exception e){
      			JOptionPane.showMessageDialog(null,e);
      			dispose();
    		}
	}
}
